


// 1) simple text-based feature, replace the webpage's main heading



// 2) something a bit more complicated, replace selected elements with lorem ipsum



// 3) We wrap what we did in 2) in a function that we can loop every second 
//    (so we can apply our changes to dynamically loading pages)



// 4) Last example, we filter the text for words that we replace with other words


