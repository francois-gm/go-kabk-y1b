

// always declare your variables first



// then declare your event listeners



