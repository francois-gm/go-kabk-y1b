

// always declare your variables first


// set inital value to zero

// select value and buttons


// then declare your event listeners


